export { default as WechatPay } from './WechatPay';
export { default as WechatOauth } from './WechatOauth';
export { default as WechatApi } from './WechatApi';